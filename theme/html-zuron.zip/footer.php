<footer class="footer" style="margin-left: 0; width:100%">
	<div class="container-fluid clearfix">
		<span class="float-right">
			<a href="#">Zuron Admin</a> © 2018-2019
		</span>
	</div>
</footer>
<script src="js/jquery.min.js" type="text/javascript"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


<!-- <script src="js/custom.js" type="text/javascript"></script>-->

</body>

</html>
